<?php
include('server.php');
//รับค่าตัวแปรจาก edit_topic
$topic_id = $_POST['top_id'];
$topic_name = $_POST['top_name'];
$topic_con = $_POST['top_con'];

// แก้ไขข้อมูลใน DB
$sql = "UPDATE topics SET topicName = '$topic_name',topicContent = '$topic_con' WHERE topicID = '$topic_id'";
$result = mysqli_query($conn,$sql);
// แก้ไขข้อมูลใน DB เรียบร้อย

if($result){
    echo "<script>alert('แก้ไขกระทู้เรียบร้อย');</script>";
    echo "<script>window.location= 'my_web_board_page.php';</script>";
}else{
    echo "<script>alert('ไม่สามารถแก้ไขกระทู้ได้');</script>";
}
mysqli_close($conn);

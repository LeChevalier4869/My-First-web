<?php
include('server.php');
//รับค่าตัวแปรจาก add_topic
$get_user_id = $_GET['userID'];
$topic_name = $_POST['top_name'];
$topic_con = $_POST['top_con'];
//เพิ่มข้อมูลกระทู้ลงตาราง topics
$sql = "INSERT INTO topics (topicName,topicContent,userID) VALUES ('$topic_name','$topic_con','$get_user_id')";
$result = mysqli_query($conn,$sql);
if($result){
    echo "<script>alert('เพิ่มกระทู้เรียบร้อย');</script>";
    echo "<script>window.location= 'all_blog.php';</script>";
}else{
    echo "<script>alert('ไม่สามารถเพิ่มกระทู้ได้');</script>";
}
mysqli_close($conn);

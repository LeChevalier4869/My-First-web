<?php
session_start();
include('server.php');
//รับค่าตัวแปรจาก login
$username = $_POST['username'];
$password = $_POST['password'];


// $password = md5($password);//เข้ารหัส
//ตรวจสอบ username และ password ในตาราง users
$sql = "SELECT * FROM users WHERE userName = '$username' AND userPassword = '$password'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result);

//ถ้าเงื่อนไขถูกต้อง เข้าหน้า homepage พร้อมกับส่ง SESSION username และ password ที่ได้รับจาก DB
//ถ้าเงื่อนไขผิด login อีกรอบ
if($row >0){
    $_SESSION["userID"] = $row['userID'];
    $_SESSION["userName"] = $row['userName'];
    $_SESSION["password"] = $row['userPassword'];
    $_SESSION["userEmail"] = $row['userEmail'];
    $_SESSION["fName"] = $row['fName'];
    $_SESSION["lName"] = $row['lName'];
    header("location:index.php");
}else{
    $_SESSION["Error"] = "Your username or password is invalid";
    // echo mysqli_num_rows($result);
    header("location:login2.php");
}

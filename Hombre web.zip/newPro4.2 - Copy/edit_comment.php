<?php
include('server.php');
//รับค่า topicID จาก show_topic.php
$get_comments_id = $_GET['commentID'];
$sql = "SELECT * FROM comments WHERE commentID = '$get_comments_id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Comment</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>

<body>
    <!-- แก้ไขชื่อกระท้อและรายละเอียด -->
    <div class="container">
        <form method="POST" action="update_comment.php">
            <div class="h4 text-center alert alert-dark md-3 mt-3" role="alert">แก้ไขการตอบกระทู้</div>
            <label>ID Comment</label>
            <input type="text" name="com_id" class="form-control" readonly value="<?= $row['commentID'] ?>"><br>
            <label>Comment</label>
            <input type="text" name="com_con" class="form-control" value="<?= $row['commentContent']?>"><br>
            <input type="submit" value="Update" class="btn btn-success">
            <a href="my_comments_page.php" class="btn btn-danger">cancel</a>
        </form>
    </div>
</body>

</html>
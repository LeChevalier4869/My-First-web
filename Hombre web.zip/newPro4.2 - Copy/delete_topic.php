<?php
include('server.php');
//รับค่า topicID จาก show_topic.php
$get_topic_id = $_GET['topicID'];
// ลบข้อมูลออกจากตาราง topics
$sql1 = "DELETE FROM topics WHERE topicID = '$get_topic_id'";
$sql2 = "DELETE FROM comments WHERE topicID = '$get_topic_id'";
if(mysqli_query($conn, $sql2)){
    if (mysqli_query($conn, $sql1)) {
        echo "<script>alert('ลบกระทู้เรียบร้อย');</script>";
        echo "<script>window.location= 'my_web_board_page.php';</script>";
        // กลับไปหน้า show_topic
    } else {
        echo "Error : " . $sql1 . "<br>" . mysqli_error($conn);
        echo "<script>alert('ไม่สามารถเพิ่มกระทู้ได้');</script>";
    }
}
mysqli_close($conn);

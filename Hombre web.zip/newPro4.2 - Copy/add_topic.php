<?php
session_start();
include('server.php');
$get_user_id = $_GET['userID'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Topic</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/headfoot/style.css">
    <link rel="stylesheet" href="css/nav/style.css">
</head>

<nav>
        <div class="logo">
            <a href="index.php">Hombre</a>
        </div>
        <div class="menu">
            <div class="menu-bar">
                <li><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                <li><a class="nav-link" href="all_blog.php">Blog</a></li>
            </div>

            <ul class="menu">
                <!--Logout ยังไม่เสร็จ-->
                <?php if (isset($_SESSION['userID'])) { ?>
                    <li class="nav-item dropdown mr-200px ">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $_SESSION["userName"] ?> <!--ดึงข้อมูล userName มาใส่ไว้ตรงนี้-->
                        </a>
                        <ul class="dropdown-menu mx-auto">
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="my_web_board_page.php">My blog</a></li>
                            <li><a class="dropdown-item" href="my_comments_page.php">My comment</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php } else { ?>
                    <li class="nav-item mx-auto">
                        <button class="btn btn-outline-success" type="submit"><a href="login2.php">Login</a></button>
                        <button class="btn btn-outline-success" type="submit"><a href="register.php">Register</a></button>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </nav>

<body>
    <!-- input data LOGIN -->
    <div class="container">
        <form method="POST" action="insert_topic.php?userID=<?=$get_user_id?>">
            <div class="h4 text-center alert alert-dark md-3 mt-3" role="alert">เพิ่มกระทู้</div>
            <label>ชื่อกระทู้</label>
            <input type="text" name="top_name" class="form-control" placeholder="ชื่อกระทู้" required><br>
            <label>รายละเอียด</label>
            <input type="text" name="top_con" class="form-control" placeholder="รายละเอียด" required><br>
            <input type="submit" value="submit" class="btn btn-success">
            <a href="all_blog.php" class="btn btn-danger">cancel</a>
        </form>
    </div>

</body>

</html>
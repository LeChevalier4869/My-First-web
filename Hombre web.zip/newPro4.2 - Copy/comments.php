<?php
include('server.php');
session_start();

if (!isset($_SESSION['userID'])) {
    header('location: login2.php'); 

}else{
    //รับค่า topicID และ comments จาก show_topic.php
$get_topic_id = $_GET['topicID'];
$myID = $_SESSION['userID'];
$comments = $_POST['comments'];
// บันทึกข้อมูลลงตาราง comments
$sql = "INSERT INTO comments (commentContent,userID,topicID) VALUES ('$comments','$myID','$get_topic_id')";
$result = mysqli_query($conn, $sql);
$_SESSION["topic_id"] = $get_topic_id;
header("location:show_topic.php");
//บันทึกเรียบร้อย
}

// //รับค่า topicID และ comments จาก show_topic.php
// $get_topic_id = $_GET['topicID'];
// $myID = $_SESSION['userID'];
// $comments = $_POST['comments'];
// // บันทึกข้อมูลลงตาราง comments
// $sql = "INSERT INTO comments (commentContent,userID,topicID) VALUES ('$comments','$myID','$get_topic_id')";
// $result = mysqli_query($conn, $sql);
// $_SESSION["topic_id"] = $get_topic_id;
// header("location:show_topic.php");
// //บันทึกเรียบร้อย

<!-- logout -->
<?php
session_start();
session_destroy();
unset($_SESSION['username']);
unset($_SESSION['userID']);
unset($_SESSION['password']);
unset($_SESSION['userEmail']);
unset($_SESSION['fName']);
unset($_SESSION['lName']);
unset($_SESSION['Error']);
header("location:index.php");
?>

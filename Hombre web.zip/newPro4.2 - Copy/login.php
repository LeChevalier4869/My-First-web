<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="h5 text-center alert alert-dark md-2 mt-2" role="alert">Login</div>
                <form action="login_check.php" method="POST">
                    <!-- ใส่ข้อมูล username และ password เพื่อ login -->
                    username<input type="text" name="username" class="form-control" required>
                    password<input type="password" name="password" class="form-control" required>
                    <?php
                    //หากมี session error โชว์ error
                    if (isset($_SESSION["Error"])) {
                        echo "<div class='text-danger'>";
                        echo $_SESSION["Error"];
                        echo "</div>";
                    } ?><br>
                    <!-- ส่งข้อมูลไปให้ login_check -->
                    <input type="submit" name="submit" value="Login" class="btn btn-primary">
                    <input type="reset" name="reset" value="reset" class="btn btn-primary"><br>
                    <a href="register.php">Register</a>
                </form>
            </div>
        </div>
    </div>

</body>

</html>
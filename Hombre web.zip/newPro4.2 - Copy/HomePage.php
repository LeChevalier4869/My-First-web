<?php
session_start();
include('server.php');
?>

<!DOCTYPE html>
<html>

<head>
  <title>Apache</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style2.css">

</head>
<a href="logout.php">Logout</a>

<section class="navbar">
  <div class="logo">
    <h1><a href="HomePage.html"><img src="Logo/Logo.png" width="250" height="50"></a></h1>
  </div>
  <ul class="dropdown-menu mx-auto">
    <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
    <li><a class="dropdown-item" href="my_web_board_page.php">My blog</a></li>
    <li><a class="dropdown-item" href="my_comments_page.php">My comment</a></li>
    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
  </ul>
</section>

<header>
  <div class="header-info">
    <h1>Welcome to my website</h1>
    <p> loremsssssssssssssssssssssssssssssssssssssssssssssssssssssssssss,
      ssssssssssssssssssssssssssssssssssssssssssssssssssss,
      ssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaa,
      aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa s s s s s s s,
      s dadw , asd wad,
      d wa,d wa,
      d awda w, daw da wd ada dwa dw adasd wad saw asd wasd wasd wa,
      d awda sdd wa dwa dsd awd sad wsa wdawd saa awdasd wasd wa sd ,w
      a wda wd asd wad adssd wa sdwad asd w ad as awd as wa d sad w ads
      awdawd awd aw aw daw d sa d as dw wa sd wa sd wa d aw awd as aw d
      a wda wda sd wa sd wa ds wa dwa s wsa w as aw dawd a sd wad s sd w
      d awd adw as aw as dwa dsa dwad asd awd ad w awd awd ad asd wa d
    </p>
    <a href="#" class="header-btn">Learn more</a>
  </div>
</header>
<?php
$sql = "SELECT * FROM topic"; // เปลี่ยน "ชื่อตาราง" เป็นชื่อตารางที่ต้องการดึงข้อมูล  
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
?>
    <section class="teams">

      <div class="teams-items">
        <?php
        echo $row["topicname"];
        ?>
        <a href="#">more</a>
      </div>

    <?php
  } ?>
  <?php
} ?>


    </section>

    <footer>
      <div class="footer">
        <div class="footer2">
          <p>&copy; 2023 by Arnon and The gangs</p>
        </div>
      </div>
    </footer>

</html>
<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style3.css">
</head>

<body>
    <div class="wrapper">
        <form action="login_check.php" method="POST">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="username" required>
                <!-- <i class='bx bxs-user'></i> -->
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="password" required>
                <!-- <i class='bx bxs-lock-alt'></i> -->
            </div>
            <?php
                    //หากมี session error โชว์ error
                    if (isset($_SESSION["Error"])) {?>
                        <div class='text-danger'>
                            <?php echo $_SESSION["Error"] ;
                              unset($_SESSION["Error"]);
                              $errors = 0;
                            ?>

                        </div>
                    <?php } ?>
            <button type= "submit" class="btn">Login</button>
            <!-- <input type="submit" name="submit" value="Login" class="btn btn-primary"> -->
            <div class="register-link">
                <p>Dont have a account? <a href="register.php">Register</a></p>
            </div>
        </form>
    </div>

</body>
</html>

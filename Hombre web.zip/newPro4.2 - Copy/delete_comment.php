<?php
include('server.php');
//รับค่า commentID
$get_comment_id = $_GET['commentID'];
// ลบข้อมูลออกจากตาราง comments
$sql = "DELETE FROM comments WHERE commentID = '$get_comment_id'";
if(mysqli_query($conn, $sql)){
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('ลบการตอบกระทู้เรียบร้อย');</script>";
        echo "<script>window.location= 'my_comments_page.php';</script>";
        // กลับไปหน้า show_comment
    } else {
        echo "Error : " . $sql . "<br>" . mysqli_error($conn);
        echo "<script>alert('ไม่สามารถลบการตอบกระทู้ได้');</script>";
    }
}
mysqli_close($conn);

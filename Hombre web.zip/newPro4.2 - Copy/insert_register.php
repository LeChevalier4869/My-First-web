<?php
include('server.php');
session_start();
//รับค่าตัวแปรจาก register
$firtname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$email = $_POST['email'];
$password_1 = $_POST['password1'];
$password_2 = $_POST['password2'];
$errors = 0;
// $password_2 = $_POST['password2'];


if ($password_1 != $password_2) {
    $_SESSION["Error"] = "passwords do not match";
    $errors++;
    // header("location:register.php");
}

$user_check = "SELECT * FROM users WHERE userName='$username' OR userEmail='$email'";
$query = mysqli_query($conn, $user_check);
$result = mysqli_fetch_array($query);

if ($result>0) {
    $_SESSION["Error"] = "username or email already exists";
    $errors++;
    // header("location:register.php");
}
//เพิ่มข้อมูลลงตาราง user
if ($errors == 0) {
    $sql = "INSERT INTO users (userName,userPassword,userEmail,fName,lName) 
VALUES ('$username','$password_1','$email','$firtname','$lastname')";
    $result1 = mysqli_query($conn, $sql);
    //บันทึกเรียบร้อย
    echo "<script> alert(สมัครสมาชิกเรียบร้อย); </script>";
    echo "<script> window.location='login2.php' </script>";
} else {
    echo "<script> alert(สมัครสมาชิกไม่สำเร็จ); </script>";
    echo "<script> window.location='register.php' </script>";
}
mysqli_close($conn);

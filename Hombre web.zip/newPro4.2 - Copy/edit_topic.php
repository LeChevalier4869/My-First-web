<?php
include('server.php');
//รับค่า topicID จาก show_topic.php
$get_topic_id = $_GET['topicID'];
$sql = "SELECT * FROM topics WHERE topicID = '$get_topic_id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Topic</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>

<body>
    <!-- แก้ไขชื่อกระท้อและรายละเอียด -->
    <div class="container">
        <form method="POST" action="update_topic.php">
            <div class="h4 text-center alert alert-dark md-3 mt-3" role="alert">แก้ไขกระทู้</div>
            <label>ID กระทู้</label>
            <input type="text" name="top_id" class="form-control" readonly value="<?= $row['topicID'] ?>"><br>
            <label>ชื่อกระทู้</label>
            <input type="text" name="top_name" class="form-control" value="<?= $row['topicName'] ?>"><br>
            <label>รายละเอียด</label>
            <input type="text" name="top_con" class="form-control" value="<?= $row['topicContent'] ?>"><br>
            <input type="submit" value="Update" class="btn btn-success">
            <a href="my_web_board_page.php" class="btn btn-danger">cancel</a>
        </form>
    </div>
</body>

</html>
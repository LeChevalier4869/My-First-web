<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COMHUB.com</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/headfoot/style.css">
    <link rel="stylesheet" href="css/index/style.css">
    <link rel="stylesheet" href="css/nav/style.css">

</head>

<body>
    <nav>
        <div class="logo">
            <a href="index.php">Hombre</a>
        </div>
        <div class="menu">
            <div class="menu-bar">
                <li><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                <li><a class="nav-link" href="all_blog.php">Blog</a></li>
            </div>

            <ul class="menu">
                <!--Logout ยังไม่เสร็จ-->
                <?php if (isset($_SESSION['userID'])) { ?>
                    <li class="nav-item dropdown ml-end">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      
                                <?php echo $_SESSION["userName"] ?> <!--ดึงข้อมูล userName มาใส่ไว้ตรงนี้-->
                          
                        </a>
                        <ul class="dropdown-menu mx-auto">
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="my_web_board_page.php">My blog</a></li>
                            <li><a class="dropdown-item" href="my_comments_page.php">My comment</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php } else { ?>
                    <li class="nav-item ml-end">
                        <button class="btn btn-outline-dark" type="submit"><a href="login2.php">Login</a></button>
                        <button class="btn btn-outline-dark" type="submit"><a href="register.php">Register</a></button>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </nav>

    <div id="carouselExample" class="carousel slide">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://plus.unsplash.com/premium_photo-1670689707741-834c162fdba1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8dGhhaXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=1280&h=400&q=60" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1580327942498-53a877c6d0ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dGhhaXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=1280&h=400&q=60" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8dGhhaXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=1280&h=400&q=60" class="d-block w-100" alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>


    <div class="content">
        <h1>เนื้อหาทั้งหมด</h1>
    </div>
    <div class="container">
        <div class="card">
            <div class="con-topic">
                <img src="https://plus.unsplash.com/premium_photo-1670002340314-0136d5cd5dd1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NDB8fHRoYWklMjB0cmFkaXRpb25hbHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=1&h=1&q=60" class="card-img-top" alt="...">
                <br>
                <div class="card-body">
                    <br>
                    <h5 class="card-title">วัฒนธรรมและประเพณี</h5>
                    <br>
                    <p class="card-text">สรรพสิ่งทางวัฒนธรรมและประเพณีที่เป็นเอกลักษณ์ของประชาชนและประเทศไทย ซึ่งรวมถึงความเชื่อทางศาสนาและคำสั่งสอนในการดำเนินชีวิตประจำวัน
                        ประกอบด้วยองค์ประกอบต่างๆ ที่มีอิทธิพลต่อพฤติกรรมและวิถีชีวิตของคนไทย</p>
                    <a href="Page1.php" class="btn btn-primary">Show more</a>
                </div>
            </div> 
        </div>
    </div>


    <footer>
        <strong><p>&copy; 2023 by Arnon and The gangs</p></strong>
        <!-- <div class="footer">
        <div class="footer2">
            <p>&copy; 2023 by Arnon and The gangs</p>
        </div>
    </div> -->
    </footer>
</body>

</html>
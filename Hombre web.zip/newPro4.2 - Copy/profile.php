<?php
include('server.php');
session_start();
//รับค่า topicID จาก webboard
$get_user_id = $_SESSION['userID'];
// ดึงข้อมูลจาก DB ที่มี topicID ตรงกับตัวแปร
$sql1 = "SELECT * FROM topics WHERE userID = '$get_user_id'";
$sql2 = "SELECT COUNT(topicID) FROM topics WHERE userID = '$get_user_id'";
$sql3 = "SELECT COUNT(commentID) FROM comments WHERE userID = '$get_user_id'";
$result1 = mysqli_query($conn, $sql1);
$result2 = mysqli_query($conn, $sql2);
$result3 = mysqli_query($conn, $sql3);
$row1 = mysqli_fetch_array($result1);
$row2 = mysqli_fetch_array($result2);
$row3 = mysqli_fetch_array($result3);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="st.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="css/headfoot/style.css">
    <link rel="stylesheet" href="css/profile/style.css">
    <link rel="stylesheet" href="css/nav/style.css">
    <title>Profile</title>
</head>

<nav>
    <div class="logo">
        <a href="index.php">Hombre</a>
    </div>
    <div class="menu">
        <div class="menu-bar">
            <li><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
            <li><a class="nav-link" href="all_blog.php">Blog</a></li>
        </div>

        <ul class="menu">
            <!--Logout ยังไม่เสร็จ-->
            <?php if (isset($_SESSION['userID'])) { ?>
                <li class="nav-item dropdown mr-200px ">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo $_SESSION["userName"] ?> <!--ดึงข้อมูล userName มาใส่ไว้ตรงนี้-->
                    </a>
                    <ul class="dropdown-menu mx-auto">
                        <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                        <li><a class="dropdown-item" href="my_web_board_page.php">My blog</a></li>
                        <li><a class="dropdown-item" href="my_comments_page.php">My comment</a></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            <?php } else { ?>
                <li class="nav-item mx-auto">
                    <button class="btn btn-outline-success" type="submit"><a href="login2.php">Login</a></button>
                    <button class="btn btn-outline-success" type="submit"><a href="register.php">Register</a></button>
                </li>
            <?php } ?>
        </ul>
    </div>
</nav>

<body>
    <br>
    <br>
    <div class="container">
        <header class="header content"></header>
        <main class="main_content">
            <div class="profile">
                <figure>
                    <div class="pic"><img src="https://www.mgp.net.au/wp-content/uploads/2023/05/150-1503945_transparent-user-png-default-user-image-png-png.png" alt=""></div>
                </figure>
                <figcaption>
                    <div class="item">
                        <label for="">ID</label>
                        <p><?= $_SESSION["userID"] ?></p>
                    </div>
                    <div class="item">
                        <label for="">Username</label>
                        <p><?= $_SESSION["userName"] ?></p>
                    </div>
                    <div class="item">
                        <label for="">Email</label>
                        <p><?= $_SESSION["userEmail"] ?></p>
                    </div>
                    <div class="item">
                        <label for="">Name</label>
                        <p><?= $_SESSION["fName"] ?></p>
                    </div>
                    <div class="item">
                        <label for="">Surname</label>
                        <p><?= $_SESSION["lName"] ?></p>
                    </div>
                </figcaption>
            </div>
            <div class="comments">
                <div class="box"><div class="top-com">
            <div class="top-h">

                <div class="top">
                    <tr>
                        <td><strong>Number of <?= $_SESSION["userName"] ?>'s topic</strong></td>
                       
                    </tr>
                </div>

                <div class="top-num">
                    <tr>
                        <td><h1><?= $row2["COUNT(topicID)"] ?></h1></td>
                       
                    </tr>
                </div>

            </div>

            <div class="com-h">

                <div class="com">
                    <tr>   
                        <td><strong>Number of <?= $_SESSION["userName"] ?>'s comment</strong></td>
                   
                    </tr>            
                </div>

                <div class="com-num">
                    <tr>   
                        <td><h1><?= $row3["COUNT(commentID)"] ?></h1></td>
                        
                    </tr>            
                </div>

            </div>

        </div></div>
                  
            </div>
        </main>
        <footer>
            <strong>
                <p>&copy; 2023 by Arnon and The gangs</p>
            </strong>
        </footer>

    </div>
</body>

</html>
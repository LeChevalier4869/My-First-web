<?php
session_start();
include('server.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Board</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <div class="h4 text-center alert alert-dark md-3 mt-3" role="alert">แสดงกระทู้</div>
        <!-- ปุ่มเพิ่มกระทู้ -->
        <a href="add_topic.php?userID=<?= $_SESSION['userID'] ?>" class="btn btn-success mb-4">ADD</a>
        <table class="table table-striped-columns">
            <tr>
                <!-- โชว์ชื่อฟิลด์ -->
                <th>topicID</th>
                <th>topicname</th>
                <th>Show</th>
            </tr>
            <?php
            // ดึงข้อมูลจาก DB
            $sql = "SELECT * FROM topics";
            $result = mysqli_query($conn, $sql);
            // ดึงข้อมูลเรียบร้อย

            // แสดงกระทู้ทั้งหมด
            while ($row = mysqli_fetch_array($result)) {
            ?>
                <tr>
                    <td><?= $row['topicID'] ?></td>
                    <td><?= $row['topicName'] ?></td>
                    <!-- ปุ่มตแสดงกระทู้ -->
                    <td><a href="show_topic.php?topicID=<?= $row['topicID'] ?>" class="btn btn-primary">Show</a></td>
                </tr>
            <?php
            }
            mysqli_close($conn);
            ?>
        </table>
    </div>
</body>

</html>
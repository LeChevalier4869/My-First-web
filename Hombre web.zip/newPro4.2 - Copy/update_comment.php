<?php
include('server.php');
//รับค่าตัวแปรจาก edit_topic
$comment_id = $_POST['com_id'];
$comment_con = $_POST['com_con'];

// แก้ไขข้อมูลใน DB
$sql = "UPDATE comments SET commentContent = '$comment_con' WHERE commentID = '$comment_id'";
$result = mysqli_query($conn,$sql);
// แก้ไขข้อมูลใน DB เรียบร้อย

if($result){
    echo "<script>alert('แก้ไขการตอบกระทู้เรียบร้อย');</script>";
    echo "<script>window.location= 'my_comments_page.php';</script>";
}else{
    echo "<script>alert('ไม่สามารถแก้ไขการตอบกระทู้ได้');</script>";
}
mysqli_close($conn);

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style3.css">
</head>

<body>
    <div class="wrapper">
        <form method="POST" action="insert_register.php">
            <h1>Register</h1>
            <div class="input-box">
                <input type="text" name="firstname" placeholder="Firstname" required>
                <!-- <i class='bx bxs-user'></i> -->
            </div>
            <div class="input-box">
                <input type="text" name="lastname" placeholder="Lastname" required>
                <!-- <i class='bx bxs-user'></i> -->
            </div>
            <div class="input-box">
                <input type="text" name="username" placeholder="username" required>
                <!-- <i class='bx bxs-user'></i> -->
            </div>
            <div class="input-box">
                <input type="email" name="email" placeholder="Email" required>
                <!-- <i class='bx bxs-user'></i> -->
            </div>
            <div class="input-box">
                <input type="text" name="password1" placeholder="password" required>
                <!-- <i class='bx bxs-lock-alt'></i> -->
            </div>
            <div class="input-box">
                <input type="text" name="password2" placeholder="confirm password" required>
                <!-- <i class='bx bxs-lock-alt'></i> -->
            </div>
            <?php
                    //หากมี session error โชว์ error
                    if (isset($_SESSION["Error"])) {?>
                        <div class="text-danger">
                            <?php echo $_SESSION["Error"] ;
                            unset($_SESSION["Error"]);
                            $errors = 0;
                            ?> 
                        </div>
                    <?php } ?>
            <br>
            <button type= "submit" class="btn">Submit</button>
            <!-- <input type="submit" name="submit" value="Login" class="btn btn-primary"> -->
            
            <div class="register-link">
                <p>Do you have account? <a href="login2.php">Login</a></p>
            </div>
        </form>
    </div>

</body>
</html>

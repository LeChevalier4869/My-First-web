<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>บุญข้าวจี่</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/headfoot/style.css">
    <link rel="stylesheet" href="css/Page2/style.css">

</head>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
                    <a class="navbar-brand" href="index.php">Hombre</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto">
                        
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="all_blog.php">Blog</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav mr-auto">
                        <!--Logout ยังไม่เสร็จ-->
                        <?php if(isset($_SESSION['userID'])) {?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                  <?php echo $_SESSION["userName"] ?> <!--ดึงข้อมูล userName มาใส่ไว้ตรงนี้-->
                                </a>
                                <ul class="dropdown-menu mx-auto">
                                    <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                                    <li><a class="dropdown-item" href="my_web_board_page.php">My blog</a></li>
                                    <li><a class="dropdown-item" href="my_comments_page.php">My comment</a></li>
                                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                                </ul>
                            </li>
                        <?php }else{ ?>
                            <li class="nav-item mx-auto">
                                <button class="btn btn-outline-success" type="submit"><a href="login2.php">Login</a></button>
                                <button class="btn btn-outline-success" type="submit"><a href="register.php">Register</a></button>
                            </li>
                        <?php } ?>
                    </ul>
                    </div>
        </div>
</nav>

<body>
                            


        <footer>
            <p>&copy; 2023 by Arnon and The gangs</p>
                <!-- <div class="footer">
                <div class="footer2">
                    <p>&copy; 2023 by Arnon and The gangs</p>
                </div> 
                </div>-->
        </footer>
</body>
</html>